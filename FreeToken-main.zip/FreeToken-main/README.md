# Free Token $FREET
Free Token is a cryptocurrency which is entirely free.
www.freetoken.net


## What is $FREET?
$FREET is a simple ERC20 token on the Ethereum blockchain.

$FREET is not mintable nor pausable (we could not create more $FREET).

Total Supply & final supply is: 1,000,000,000 $FREET.

## $FREET Distribution
1st arrived, 1st served.

100% of the total supply is available through the distribution contract.

Distribution contract set a distribution cap at 1,000 $FREET per address.

## Some more questions?

### Why create a token for free?
Simple, Free Token is the future of cryptocurrencies.

### But hey! Could someone get all the stock if it is for free?
No he cannot. The distribution is capped at 1,000 $FREET per address. To get all the stock someone would need to make 1,000,000 transactions with 1,000,000 different addresses. This is impossible because of the gaz (even through multi-sender applications).

But if you want more $FREET, feel free to get more by sending 0 Ether (ETH) to the distribution contract with another Ethereum address.

### Will $FREE ever have a value some day?
When $FREET will be HODL by 1 million users it will surely have the value of the people.
And when someone decides to create a liquidity pool on Uniswap then $FREET will start to be tradable against any other cryptocurrencies. 

### Any catch?
Free Token source code is available on Github  as well as on Etherscan.io  (all contracts are verified and consultable).

### Ethereum addresses

Token address: 0x8c1b9072F78FfB869C817453dE44b2101C4DE645 
Distribution contract: 0x1B8e9B85679f845057426dd4Ba1eB1ba38319677 
Creator's address: 0x43621b2dc33FAf55c50f9713CD20f0119d8a7646 
